<template>
  <div>
    <input
      v-model="newName"
      autofocus
      @keyup.enter="createUser"
      @keyup.esc="newName = ''"
    />
    <button @click="createUser">Add</button>
    <ul v-if="names.length > 0">
      <UserCard
        v-for="(name, index) in names"
        :key="index"
        :name="name"
        :index="index"
        @toggle-status="toggleStatus(index)"
        @delete-user="deleteUser(index)"
      />
    </ul>
    <h3 v-else>No informations</h3>
  </div>
</template>

<script>
import UserCard from "./components/UserCard.vue";
export default {
  name: "App",
  components: { UserCard },
  data() {
    return {
      newName: "",
      names: [
        {
          title: "John",
          status: true,
        },
        {
          title: "Bob",
          status: true,
        },
      ],
    };
  },
  methods: {
    createUser() {
      this.names.unshift({ title: this.newName, status: true });
      this.newName = "";
    },
    deleteUser(index) {
      this.names.splice(index, 1);
    },
    toggleStatus(index){
      const user = this.names[index]
      this.names[index] = {...user, status: !user.status}
    }
  },
};
</script>

<style>

</style>
