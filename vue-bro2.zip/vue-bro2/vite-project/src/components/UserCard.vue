<template>
  <div>
    <li
      :style="{
        'text-decoration': !name.status ? 'line-through' : 'none',
        color: !name.status ? 'red' : 'black',
      }"
    >
      <span @click="$emit('toggle-status')">
        {{ index + 1 }}. {{ name.title }}
      </span>
      <button @click="$emit('delete-user')">Delete</button>
    </li>
  </div>
</template>

<script>
export default {
  name: "UserCard",
  emits: ["delete-user", "toggle-status"],
  props: {
    name: {
      type: Object,
    },
    index: {
      type: Number,
    },
  },
};
</script>

<style>
li {
  list-style-type: none;
  cursor: pointer;
}
</style>
